<html>
<!-- M.OCTAVIANO PRATAMA -->
<head>

<style type="text/css">
.head
{
	margin-left:18em;
	margin-top:4em;
	margin-right:18em;
	padding-left:18pt;
	padding-top:10pt;
	background:#04a7dd;
	height:7em;
	border-radius:25px 25px 0px 0px;
}

.head img{
	margin-left: -120px;
}

#body
{
	padding-top:18pt;
	margin-left:18em;
	margin-right:18em;
	background:#f0ee42;
	height:20em;
	border-radius:0px 0px 25px 25px;
}

#footer{
	padding-top:18pt;
	margin-left:10em;
	margin-right:18em;
}

.footer{
	margin-top: 10px;
	margin-bottom: 20px;
	font-size: 12px;
	font-weight: bold;
}
.footer .left{
	margin-left: 90px;
	float: left;
	width: 50%;
}
.footer .right{
	padding: 12px 10px 12px 2px;
}

.ttd {
	margin-top: 12px;
	font-size: 15px;
	margin-left: 100px;
	margin-right: 180px;
	float: left;
}

.ttd .ketua p{
	border-bottom: 1px solid black;
	margin-top: -12px;
	margin-bottom: 3px;
	width: 100%;
	
}

.belakang{
	margin-left:18em;
	margin-top:4em;
	margin-right:18em;
	padding-left:18pt;
	padding-top:10pt;
	background:#f0ee42;
	height:7em;
	border-radius:25px 25px 0px 0px;	
}

.body{
	padding-top:18pt;
	margin-left:18em;
	margin-right:18em;
	background:#f0ee42;
	height:20em;
	border-radius:0px 0px 25px 25px;
}

.body table{
	margin: 12px 70px;
	border: 0;
}

.top{
	margin-left: 10em;
}
</style>
</head>
<body>
<div class="head">
	<table id="header" border='0'align='center' style="font-weight: bold;">
		<tr>
			<td><img src="<?=base_url()?>assets/images/logo/pmii.jpg" width='80'height='80'/></td>
		 	<td >
		 		<p style="margin-bottom:-12px">PENGURUS CABANG KOTA MALANG</p>
		 		<p style="margin-bottom:-12px">PERGERAKAN MAHASISWA ISLAM INDONESIA</p>
		 		<p>Jln. Panjaitan No. 21 Kota Malang</p>
		 	</td>
		</tr>
	</table>
</div>
<div id="body">
	 <form >
	 <?php foreach ($data as $key ) {?>
		<table border='0' align='center'>
			<tr>
				<td rowspan='10'>
				<?php if (!empty($key['foto'])) {?>
					<img src="<?=base_url()?>assets/foto/<?=$key['foto']?>" width='180'height='150' style="margin-left: -100px; margin-top: -12px; margin-right: 30px;">
				<?php }else{?>	
					Foto tidak tersedia
				<?php };?>	
				</td>
			</tr>
			<tr>
				<td><b>Nama</b></td>
				<td><b>:</b></td>
				<td><b>V-04-02.<?=$key['kode_kom']?>.<?=$key['kode_rayon']?>.<?=$key['kode']?></b></td>
			</tr>
			<tr>
				<td><b>Nama</b></td>
				<td><b>:</b></td>
				<td><b><?=$key['nama']?></b></td>
			</tr>
			<tr>
				<td><b>Alamat</b></td>
				<td><b>:</b></td>
				<td><b><?=$key['alamat_asal']?></b></td>
			</tr>
			<tr>
				<td>TTL</td>
				<td>:</td>
				<td><?=$key['lahir']?>, <?=$key['tgl_lahir']?></td>
			</tr>
			<tr>
				<td>Kampus</td>
				<td>:</td>
				<td><?=$key['kampus']?></td>
			</tr>
			<tr>
				<td>Komisariat</td>
				<td>:</td>
				<td><?=$key['nama_kom']?></td>
			</tr>
			
			<tr>
				<td>Rayon</td>
				<td>:</td>
				<td><?=$key['nama_rayon']?></td>
			</tr>
		</table>
		<?php }?>
	</form>
	<div class="footer">
		<div class="left">
			<p style="margin-bottom:-12px">PENGURUS CABANG KOTA MALANG</p>
			<p>PERGERAKAN MAHASISWA ISLAM INDONESIA</p>
		</div>
		<div class="right">
			<p>Malang, <?=$tgl;?></p>
		</div>
	</div>
	<div class="ttd">
		<div class="ketua">
			<p>Moh. Faris</p>
			Ketua Cabang
		</div>
	</div>
	<div class="ttd">
		<div class="ketua">
			<p>Muhlas Adi Putra</p>
			Sekretaris Cabang
		</div>
	</div>
</div>

<div class="belakang">
	<table id="header" border='0'align='center' style="font-weight: bold;">
		<tr>
			<td style="padding-right: 50px">
				<img src="<?=base_url()?>assets/images/logo/pmii.jpg" width='80'height='80'/>
			</td>
		 	<td >
		 		<p style="margin-bottom:-12px">PENGURUS CABANG KOTA MALANG</p>
		 		<p style="margin-bottom:-12px">PERGERAKAN MAHASISWA ISLAM INDONESIA</p>
		 		<p>Jln. Panjaitan No. 21 Kota Malang</p>
		 	</td>
		</tr>
	</table>
</div>
<div class="body">
	<table  border="0" align="justify">
		<tr rowspan="12">
			<th >Tujuan</th>
			<td style="padding: 0 5% 0 10%; ">
				<p>Terbentuknya pribadi muslim yang bertaqwa
				kepada Allah SWT, berbudi luhur, cakap dan
				bertanggung jawab dalam mengamalkan ilmunya dan
				komitmen memperjuangkan cita-cita kemerdekaan Indonesia</p>
			</td>
		</tr>
		<tr>
			<th >Peraturan</th>
			<td style="padding: 0 5% 0 10%; ">
				<p>Jika menemukan Kartu ini harap kembalikan kepada PC PMII Kota Malang
				alamat Jl. Panjaitan NO 20 atau tlpn <b><?=$key['tlp']?></b> </p>
			</td>
		</tr>
	</table>
</div>

</body>
</html>