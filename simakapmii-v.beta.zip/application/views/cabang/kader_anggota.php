<?php $this->load->view('cabang/header_cabang');?>
<div class="row">
	<div class="col-xs-12">

		<div class="row">
			<div class="col-xs-12">
				<div class="clearfix">
					<div class="tableTools-container"></div>
				</div>
			<div class="table-header">DATA ANGGOTA SE-KOTA MALANG</div>	
			

		<div class="table-responsive">
			<table id="dynamic-table" class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
						<th> Kode</th>
						<th> Foto</th>
						<th> Nama</th>
						<th> TTL</th>
						<th> ASAL</th>
						<th> Kampus</th>
						<th> fakultas</th>
						<th> Komisariat</th>
						<th> Rayon </th>
					
					</tr>
				</thead>

				<tbody>
				<?php
				foreach($data as $a){ ?>
					<tr>
						<td > <?php echo $a['kode']; ?> </td>
						<td > 
							<?php if (!empty($a['foto'])) {?>
							<img src="<?=base_url()?>assets/foto/<?php echo $a['foto']; ?>" width="100px">
							<?php }else{?>
							Tidak Ada foto
							<?php }?>
						</td>
						<td > <?php echo $a['nama']; ?>
							<a href="<?=base_url().'cabang/lihatkader/'.$a['id']?>" target="_blank">
								<span class="fa fa-eye"></span>
							</a>
						</td>
						<td > <?php echo $a['lahir']; echo " "; echo $a['tgl_lahir'];?> </td>
						<td > <?php echo $a['alamat_asal']; ?> </td>
						<td > <?php echo $a['kampus']; ?></td>
						<td > <?php echo $a['fakultas']; ?></td>
						<td > <?php echo $a['kode_kom']; ?></td>
						<td > <?php echo $a['kode_rayon']; ?>
							<i><a href="<?=base_url('cabang/kta/'). $a['id']?>" target="_blank">
								<span class="fa fa-print"></span>
							</a></i>
						</td>

					</tr>

					<?php 
					}?>
				</tbody>
				</table>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
<?php $this->load->view('cabang/footer_cabang');?>