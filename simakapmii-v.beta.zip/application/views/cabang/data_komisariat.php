<?php $this->load->view('cabang/header_cabang');?>						
<div class="row">
	<div class="col-xs-12">

	<div class="row">
		<div class="col-xs-12">

			<div class="clearfix">
				<div class="pull-right tableTools-container"></div>
				<button type="button" class="btn btn-warning btn-xs" onclick="history.back(-1)" /><span class="fa fa-arrow-left"></span> Back</button>
				<a href="<?=base_url()?>cabang/tambah_kom" class="btn btn-success btn-xs"> 
					<i class="fa fa-plus"> </i> TAMBAH DATA KOM
				</a>
			</div>
			<div class="table-header">DATA KOMISARIAT</div>	


		<div class="table-responsive">
			<table id="dynamic-table" class="table table-bordered table-hover">
				<thead>
					<tr >
						<th> NO</th>
						<th> Kode </th>
						<th> Komisariat</th>
						<th> Kampus</th>
						<th> Tlpn</th>
						<th> Email</th>
						<th> Alamat</th>
						<th> status</th>
						<th> Action </th>
					</tr>
				</thead>

				<tbody>
				<?php if (empty($data)) {?>
				<td colspan="9"><h1 class="text-center">TIDAK ADA DATA <span class="fa fa-database"></span></h1></td>
				<?php }else{
				$i = 1;
				foreach($data as $kom){ ?> 
					
					<tr>
						<td > <?php echo $i; ?> </td>
						<td > <?php echo $kom ['kode_kom']; ?></td>
						<td > <?php echo $kom ['nama_kom']; ?></td>
						<td > <?php echo $kom ['kampus']; ?> </td>
						<td > <?php echo $kom ['no_telp']; ?></td>
						<td > <?php echo $kom ['email']; ?></td>
						<td > <?php echo $kom ['alamat']; ?> </td>
						<td > <?php 
                        		if ($kom['status'] == 'active') {
                        			echo "<span class='btn btn-xs btn-success'>Active</span>";
                        		}else{
                        			echo "<span class='btn btn-xs btn-warning'>Inactive</span>";
                        		}
                        	;?> </td>
						<td > 
							<i><a href="<?php echo base_url()."cabang/edit_kom/".$kom['id_kom'] ?>"> <span class="btn btn-xs btn-info fa fa-edit"></span></a></i>
							<i><a href="<?php echo base_url ()."cabang/delete_kom/".$kom['kode_kom']; ?>" onclick="return confirm('yakin !!');"> <span class="btn btn-xs btn-danger fa fa-trash"></span></a></i>
							<i><a href="<?=base_url().'cabang/getById/'.$kom['kode_kom'];?>"><span class="btn btn-xs btn-success fa fa-folder-open"></span></a></i>
							<i><a href="<?=base_url().'cabang/profile_kom/'.$kom['kode_kom'];?>"><span class="btn btn-xs btn-primary fa fa-user"></span></a></i>
						</td>

					</tr>

					<?php $i++;
						}
					}?>
				</tbody>
				</table>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>

<?php $this->load->view('cabang/footer_cabang');?>