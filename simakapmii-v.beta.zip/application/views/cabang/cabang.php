<?php $this->load->view('cabang/header_cabang');?>

					
<div class="page-header">
	<h1>
		ADMIN CABANG
	</h1>
</div><!-- /.page-header -->

<div class="alert alert-block alert-info text-center">
	<button type="button" class="close" data-dismiss="alert">
		<i class="ace-icon fa fa-times"></i>
	</button>
	<p>
		<img class="img-responsive img-thumbnail" src="<?=base_url();?>assets/images/logo/pc_pmii.jpg"  />
	</p>	
</div>
<!--starai row isi konten-->

<!--starai row-->

</div><!-- /.page-content -->
</div>
</div><!-- /.main-content -->

<?php $this->load->view('cabang/footer_cabang');?>