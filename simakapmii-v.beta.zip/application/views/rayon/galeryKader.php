<?php $this->load->view('rayon/header_pr');?>
		

<?php $this->load->view('rayon/footer_pr');?>