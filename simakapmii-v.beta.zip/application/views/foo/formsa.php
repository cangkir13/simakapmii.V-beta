<?php $this->load->view('foo/footerfoo');?>

<div class="container">
<h2 class="text-center"> <b> FORM <?php echo isset($data)? 'EDIT':'TAMBAH';?> ADMIN </b> <hr /> </h2>

<?php $class = "class = 'form-horizontal'";
echo form_open('foo/fooupdate', $class, array('id_user'=>$data[0]['id_user'])) ;?>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> User Name </label>

		<div class="col-sm-9">
			
			<input type="text" id="form-field-1" placeholder="Nick Name or anything" class="form-control" required="" value="<?= isset($data)? $data[0]['user_name']:'';?>"/>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Status </label>

		<div class="col-sm-2">
			<?php
        		$options = array(
        					''		   => '=== Pilih ===',
					        'active'   => 'Active',
					        'inactive' => 'Nonactive',
					);

					$class = 'class="form-control" required';
					echo form_dropdown('status', $options, '', $class);
        	?>
			
		</div>
	</div>

	
	<div class="form-group">
		<div class="col-sm-3 text-right">
			<button type="button" class="btn btn-warning" onclick="history.back(-1)" /><span class="fa fa-arrow-left"></span> Back</button>
		</div>

		<div class="col-sm-9">
			<button type="reset" class="btn btn-danger" data-dismiss="modal"><span class="fa fa-repeat"></span> Reset</button>
			<button type="submit" class="btn btn-primary"> <span class="fa fa-save"></span> Save </button>
		</div>
	</div>

</form>	
</div>