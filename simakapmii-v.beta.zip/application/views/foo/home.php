<?php $this->load->view('foo/footerfoo');?>
<div class="container">
	<div class="row">
        <div class="col-md-12 col-xs-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Admin Cabang</h3>
                </div>
                <div class="panel-body table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $i=1;
                        foreach ($data as $key) {?>
                            <tr>
                                <td><?php echo $i;?></td>
                                <td><?php echo $key['user_name'];?></td>
                                <td><?php echo $key['pass'];?></td>
                                <td>
                                	<?php 
                                		if ($key['status'] == 'active') {
                                			echo "<span class='btn btn-xs btn-success'>Active</span>";
                                		}else{
                                			echo "<span class='btn btn-xs btn-warning'>Inactive</span>";
                                		}
                                	;?>
                                    
                                </td>
                                <td>
                                	<a href="<?=base_url().'foo/formedit/'.$key['id_user']?>" class="btn btn-xs btn-info"><span class="fa fa-edit"></span> </a>
                                	<a href="" class="btn btn-xs btn-danger"><span class="fa fa-trash"></span> </a>
                                </td>
                            </tr>
                        <?php $i++;
                        }?>    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

</body>
</html>