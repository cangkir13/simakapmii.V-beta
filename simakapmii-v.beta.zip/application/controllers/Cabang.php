<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cabang extends CI_Controller{

  public function __construct(){
    parent::__construct();
    $this->load->model('foo_model');
     if(! $this->session->has_userdata('user'))
        {
          $this->session->set_flashdata("alert_pro", "<div class='modal fade' id='myModal'><div class='modal-dialog'><div class='alert alert-danger'><h2 class='form-signin-heading'>OJOK MEKSO, LOGIN RUMIYEN!!!</h2></div></div><button type='button' class='btn btn-danger' data-dismiss='modal'><span class='fa fa-close'></span> Close</button></div><script type='text/javascript'>$('#myModal').modal('show');</script>");
          redirect('dashboard/pc', 'refresh');
        }
    $this->load->model('app_model');
  }

  public function index(){
    $data['title'] = 'Welcome';
    $this->load->view('cabang/cabang', $data);
  }

	public function get_all(){
    $data['title'] = "ALL Admin";
    $data['data'] = $this->modeladmin->getadmin();
  	$this->load->view('cabang/data_admin', $data);   	
  }

  public function insert_admin(){
    $Username = $_POST ["user_name"];
    $Password = do_hash($this->input->post('pass'), "MD5");
    $Email = $_POST ["email"];
    $Level = $_POST ["level"];
    $Divisi = $_POST ["divisi"];
    $data_insert = array(
        'user_name' => $Username,
        'pass' => $Password,
        'email' => $Email,
        'level' => $Level,
        'divisi' => $Divisi,
        'status' => 'inactive'
      );
    $res = $this->db->insert('tb_admin',$data_insert);
      if ($res>=1){
        $this->session->set_flashdata('pesan','Tambah DAta Sukses');
        redirect ('cabang/get_all');
      }else{echo "Insert DATA GAGAL";
    }
  }

  public function del_admin($id_user){
    $where = array('id_user'=>$id_user);
    $res = $this->modeladmin->delete_admin('tb_admin',$where); 
    if ($res > 0) {
      redirect('cabang/get_all');
    }else{
      echo "gagal";
    }
  }

  public function edit_admin($id_user){
    $data['title'] = "Edit Data";
    $data['data'] = $this->modeladmin->getadmin("where id_user = '$id_user'");
    $this->load->view('cabang/add_admin',$data);

  }

  public function update_admin(){
    $Iduser = $_POST ["id_user"];
      $Username = $_POST ["user_name"];
      $Password = do_hash($this->input->post('pass'), "MD5");
      $Email = $_POST ["email"];
      $Level = $_POST ["level"];
      $Divisi = $_POST ["divisi"];
      $data_update = array(
        'user_name' => $Username,
        'pass' => $Password,
        'email' => $Email,
        'level' => $Level,
        'divisi' => $Divisi 
        );
      $where = array('id_user'=>$Iduser);
      $res = $this->db->update('tb_admin',$data_update,$where);
      if ($res>=1){
        redirect ('cabang/get_all');
      }
      
  }
  
  public function delete_admin($id_user){
    $where = array('id_user' =>$id_user);
    $res  = $this->modeladmin->del_admin('tb_admin',$where);
    if($res>=1){
      redirect('cabang/get_all');
    }else{
      echo "delete gagal";
    }
    
  } 

  public function get_komisariat(){
    $data['title'] = "Data komisariat";
    $data['data'] = $this->mkom->komisariat();
    $this->load->view('cabang/data_komisariat', $data);
  }

  public function add_data_kom(){
    $kode_kom = $_POST['kode_kom'];
    $nama_kom = $_POST['nama_kom'];
    $kampus   = $_POST['kampus'];
    $password = do_hash($this->input->post('password'), "MD5");
    $status   = $this->input->post('status');
    
      $data_insert = array(
        'kode_kom' => $kode_kom,
        'nama_kom' => $nama_kom,
        'kampus'   => $kampus,
        'username' => $kode_kom,
        'password' => $password
      );
      $res = $this->db->insert('tb_komisariat',$data_insert);
      if ($res >=1) {
        redirect ('cabang/get_komisariat');
      }else{
        echo "<h1> data gagal disimpan </h1> ";
      }
  }

  public function edit_kom($id_kom){
    $data['title'] = "Edit Data";
    $data['data'] = $this->mkom->get_kom("where id_kom = '$id_kom'" );
    $this->load->view('cabang/add_kom',$data);
  }

  public function update_kom(){
    $Id_kom = $_POST ["id_kom"];
    $kode_kom = $_POST['kode_kom'];
    $nama_kom = $_POST['nama_kom'];
    $kampus   = $_POST['kampus'];
    $password = do_hash($this->input->post('password'), "MD5");
    $data_update = array(
        'kode_kom' => $kode_kom,
        'nama_kom' => $nama_kom,
        'kampus'   => $kampus,
        'username' => $kode_kom,
        'password' => $password
        );
    $where = array ('id_kom'=>$Id_kom);
    $res = $this->db->update('tb_komisariat', $data_update, $where);
    if ($res>=1) {
      redirect('cabang/get_komisariat');
    }else{
      echo "data gagal di update !!!";
    }
  }

  public function delete_kom($id_kom){
    $where = array('kode_kom' =>$id_kom);
    $res = $this->mkom->del_kom('tb_komisariat',$where);
    $res2 = $this->mkom->del_kom('tb_rayon',$where);
    $res3 = $this->mkom->del_kom('tb_kader_anggota', $where);
    if ($res>=1 && $res2 > 0) {
      redirect('cabang/get_komisariat');
    }else{
      echo "Delete Gagal";
    }

  }

  public function get_rayon(){
    $data['title'] = "Data Rayon";
    $data['kom'] = $this->mkom->get_kom();
    $data['data'] = $this->mrayon->path_data_rayon();
    $this->load->view('cabang/data_rayon', $data);
  }

  public function insert_data_rayon(){
    $kode_kom   = $this->input->post('kode_kom');
    $kode_rayon = $this->input->post('kode_rayon');
    $nama_rayon = $this->input->post('nama_rayon');
    $password   = $this->input->post('password');
    $fakultas   = $this->input->post('fakultas');
      
      $data_update = array(
        'kode_kom' => $kode_kom,
        'kode_rayon' => $kode_rayon,
        'nama_rayon' => $nama_rayon,
        'username'  => $kode_rayon,
        'password'  => $password,
        'fakultas'  => $fakultas
      );

      $res = $this->db->insert('tb_rayon',$data_update);
      if ($res >=1) {
        redirect ('cabang/get_rayon');
      }else{
        echo "<h1> data gagal disimpan </h1> ";
      }
  }

  public function edit_rayon($id_rayon){
    $data['title'] = "Edit Data";
    $data['kom'] = $this->mkom->get_kom();
    $data['data'] = $this->mrayon->path_all("where id_rayon = '$id_rayon'");
    $this->load->view('cabang/add_rayon',$data);
  }

  public function update_rayon(){
    $id         = $this->input->post('id_rayon');
    $kode_kom   = $this->input->post('kode_kom');
    $kode_rayon = $this->input->post('kode_rayon');
    $nama_rayon = $this->input->post('nama_rayon');
    $password   = $this->input->post('password');
    $fakultas   = $this->input->post('fakultas');

      $data_update = array(
        'kode_kom' => $kode_kom,
        'kode_rayon' => $kode_rayon,
        'nama_rayon' => $nama_rayon,
        'username'  => $kode_rayon,
        'password'  => $password,
        'fakultas'  => $fakultas
      );
    
    $where = array ('id_rayon'=>$id);
    $res = $this->mrayon->Updatedata('tb_rayon', $data_update, $where);
    if ($res>=1) {
      redirect('cabang/get_rayon');
    }else{
      echo "data gagal di update !!!";
    }
  }

  public function delete_rayon($id_rayon){
    $where = array('kode_rayon' =>$id_rayon);
    $res = $this->mkom->del_kom('tb_rayon',$where);
    $res2  = $this->model_akun->delete_rayon('tb_kader_anggota', $where);
    if ($res > 0 && $res2 > 0) {
      redirect('cabang/get_rayon');
    }else{
      echo "Delete Gagal";
    }

  }

  public function getById(){
    $id = $this->uri->segment(3);
    $data['title'] = "DATA komisariat";
    //$data['kom'] = $this->mkom->get_kom();
    $data['data'] = $this->modeladmin->get_id($id);
    $this->load->view('cabang/data_rayon', $data);
  }

  public function profile_kom(){
    $id = $this->uri->segment(3);
    $data['title'] = "PROFILE KOM";
    $data['rayon'] = $this->modeladmin->get_id($id);
    $data['data'] = $this->modeladmin->get_prof_kom($id);
    $data['kader'] = $this->modeladmin->get_prof_anggota_kom($id);
    $this->load->view('cabang/c_kom_p', $data);
  }

  public function profile_rayon(){
    $id = $this->uri->segment(3);
    $data['title'] = "PROFILE RAYON";
    $data['kader'] = $this->mrayon->get_data_kader_rayon($id);
    $data['data'] = $this->modeladmin->get_prof_rayon($id);
    $this->load->view('cabang/c_rayon_p', $data);
  }

  public function kader_anggota(){
    $data['title'] = "KADER ANGGOTA";
    $data['data'] = $this->Modelkader->get_all();
    $this->load->view('cabang/kader_anggota', $data);
  }

  public function tambah_admin(){
    $data['title'] = "KADER ANGGOTA";
    $data['kom'] = $this->mkom->get_kom();
    $this->load->view('cabang/add_admin', $data);
  }

  public function tambah_kom(){
    $data['title'] = "ADMIN CABANG";
    $data['kom'] = $this->mkom->get_kom();
    $this->load->view('cabang/add_kom', $data);
  }

  public function tambah_rayon(){
    $data['title'] = "KADER ANGGOTA";
    $data['kom'] = $this->mkom->get_kom();
    $this->load->view('cabang/add_rayon', $data);
  }

  function kta($id){
    $data['title'] = "CETAK KTA";
    $data['tgl'] = date("D M Y");
    $data['data'] = $this->Modelkader->getktakader("where id = '$id'");
    $this->load->view('cabang/kta', $data);
  }

  function gallery(){
    $data['title'] = "Gallery";
    $data['data'] = $this->Modelkader->get_all();
    $this->load->view('cabang/galery_anggota', $data);
  }

  public function lihatkader(){
    $session = $this->uri->segment(3);
    $data['title'] = "Profile Kader";
    $data['data'] = $this->mrayon->getprofile($session);
    $this->load->view('cabang/profilekader', $data);
  }

}