<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

  public function index() 
  {
    $this->load->view('landing_page');
  }

  public function pc() 
  {
    $data['title'] = "LOGIN | PC";
    $this->load->view('cabang/login_pc', $data);
  }

  public function pk() 
  {
    $data['title'] = "LOGIN | PK";
    $this->load->view('komisariat/login_pk', $data);
  }

  public function pr() 
  {
    $data['title'] = "LOGIN | PR";
    $data['data'] = $this->db->get('tb_rayon');
    $this->load->view('rayon/login_pr', $data);
  }

  public function member() 
  {
    $data['title'] = "LOGIN | MEMBER";
    $this->load->view('member/form_login' ,$data);
  }

  
}