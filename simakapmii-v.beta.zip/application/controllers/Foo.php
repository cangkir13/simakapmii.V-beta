 <?php

class Foo extends CI_Controller
{
	private $_header = "SUPER ADMIN";

	public function __construct(){
		parent::__construct();
		$this->load->model('foo_model');
	}

	public function index()
	{
		$data['title'] = $this->_header;
		$this->load->view('foo/aunt', $data);
	}

	public function foo_aunt()
	{
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Username', 'required');
		if ($this->form_validation->run()) 
		{
			$username = $this->input->post('username');
			$password = do_hash($this->input->post('password'), 'MD5');
			$data 	  = $this->foo_model->aunt_log($username, $password);
			if ($data) {
				foreach ($data->result() as $key) {
					$s = array();
					$s['username'] = $key->username;
					$s['nama']	   = $key->nama;
					$this->session->set_userdata($s);
				}

				redirect('Foo/home');
			}
			else
	      	{
		    	$this->session->set_flashdata('msg', '<h1 class="text-center ">salah poko e wkwkwk</h1>');
		    	redirect('Foo');
		    }
		}else{
			$this->session->set_flashdata('msg', 'salah pkok e');
		    redirect('Foo');
		}
	}

	public function home()
	{
		if ($this->session->has_userdata('username')) {
			$data['brand'] = $this->session->userdata('nama');
			$data['data'] = $this->foo_model->getadmin();
			$this->load->view('foo/home', $data);
		}else{
			$this->session->set_flashdata('msg', '<h1 class="text-center ">salah poko e wkwkwk</h1>');
			redirect('Foo');
		}	
	}

	
	function formedit($id_user)
	{
		if ($this->session->has_userdata('username')) {
			$data['brand'] = $this->session->userdata('nama');
			$data['data'] = $this->modeladmin->getadmin("where id_user = '$id_user'");
			$this->load->view('foo/formsa', $data);
		}else{
			$this->session->set_flashdata('msg', '<h1 class="text-center ">salah poko e wkwkwk</h1>');
			redirect('Foo');
		}
	}

	function fooupdate()
	{
		if ($this->session->has_userdata('username')) {
			$id_user = $this->input->post('id_user');
			$status = $this->input->post('status');
		    $data_update = array(
		        'status' => $status
		    );
	      	$where = array('id_user'=>$id_user);
	      	$res = $this->db->update('tb_admin',$data_update,$where);
		    if ($res>=1){
		        redirect ('foo/home');
		    }else{
		    	redirect('Foo/formsa');	
		    }
		}else{
			$this->session->set_flashdata('msg', '<h1 class="text-center ">salah poko e wkwkwk</h1>');
			redirect('Foo');
		}
	}

	public function fookom()
	{
		if ($this->session->has_userdata('username')) {
			$data['brand'] = $this->session->userdata('nama');
			$data['data'] = $this->mkom->get_kom();
			$this->load->view('foo/kom', $data);
		}else{
			$this->session->set_flashdata('msg', '<h1 class="text-center ">salah poko e wkwkwk</h1>');
			redirect('Foo');
		}	
	}

	public function foorayon()
	{
		if ($this->session->has_userdata('username')) {
			$data['brand'] = $this->session->userdata('nama');
			$data['data'] = $this->mrayon->path_data_rayon();
			$this->load->view('foo/rayon', $data);
		}else{
			$this->session->set_flashdata('msg', '<h1 class="text-center ">salah poko e wkwkwk</h1>');
			redirect('Foo');
		}	
	}
}