<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

  public function ceklogin()
  {

    if(isset($_POST['login']))
    {
      $user1 = $this->input->post('user',true);
      $pass1 = do_hash($this->input->post('pass',true), 'md5');
      $cek = $this->app_model->proseslogin($user1,$pass1);
           
      if ($cek != false){ 
           $datalogin = $this->db->get_where('tb_admin', array('user_name' => $user1, 'pass' => $pass1)) ->row();
           $this->session->set_userdata('user',$user1);
            if ($datalogin->status == 'active') {
                redirect('cabang');
            }else{
              $this->session->set_flashdata("alert_pro", "<div class='modal fade' id='myModal'><div class='modal-dialog'><div class='alert alert-danger'><h2 class='form-signin-heading'>Akunnya blum aktive hub NawaIdea</h2></div></div><button type='button' class='btn btn-danger' data-dismiss='modal'><span class='fa fa-close'></span> Close</button></div><script type='text/javascript'>$('#myModal').modal('show');</script>");
              redirect('dashboard/pc');
            }
      }else {
        $this->session->set_flashdata("alert_pro", "<div class='modal fade' id='myModal'><div class='modal-dialog'><div class='alert alert-danger'><h2 class='form-signin-heading'>SALAH COK, MATUR NUWUN!!!</h2></div></div><button type='button' class='btn btn-danger' data-dismiss='modal'><span class='fa fa-close'></span> Close</button></div><script type='text/javascript'>$('#myModal').modal('show');</script>");
       redirect('dashboard/pc');
      }
    }   
  }

  public function login_kom_validation()
  {
    $this->form_validation->set_rules('username', 'Username', 'required');
    $this->form_validation->set_rules('password', 'Password', 'required');
    if ($this->form_validation->run()) 
    {
      //true
      $username = $this->input->post('username');
      $password = do_hash($this->input->post('password',true), 'md5');
      $result = $this->model_akun->get_validation_kom($username, $password);
      if ($result) 
      {
        foreach ($result as $list) {
          $r = array();
          $r['username']    = $list['username'];
          $r['nama_kom']    = $list['nama_kom'];
          $r['kode_kom']    = $list['kode_kom'];
          $r['kampus']      = $list['kampus'];
          $this->session->set_userdata($r);
        }  
        
        redirect('komisariat');
      }
      else
      {
        $this->session->set_flashdata('error', "<div class='modal fade' id='myModal'><div class='modal-dialog'><div class='alert alert-danger'><h2 class='form-signin-heading'>SALAH COK, MATUR NUWUN!!!</h2></div></div><button type='button' class='btn btn-danger' data-dismiss='modal'><span class='fa fa-close'></span> Close</button></div><script type='text/javascript'>$('#myModal').modal('show');</script>");
        redirect('dashboard/pk');
      }
    }
    else
    {
      redirect('dashboard/pk');
    }
  }

  public function login_rayon_validation()
  {
    $this->form_validation->set_rules('username', 'Username', 'required');
    $this->form_validation->set_rules('password', 'Password', 'required');
    if ($this->form_validation->run()) 
    {
      //true
      $username = $this->input->post('username');
      $password = $this->input->post('password');
      $result = $this->model_akun->get_validation_rayon($username, $password);
      if ($result) 
      {
        foreach ($result as $list) {
          $r = array();
          $r['username']    = $list['username'];
          $r['kode_kom']    = $list['kode_kom'];
          $r['nama_rayon']  = $list['nama_rayon'];
          $r['kode_rayon']  = $list['kode_rayon'];
          $r['fakultas']    = $list['fakultas'];
          $r['kampus']      = $list['kampus'];
          $this->session->set_userdata($r);
        }  
        
        redirect('rayon');
      }
      else
      {
        $this->session->set_flashdata('error', "<div class='modal fade' id='myModal'><div class='modal-dialog'><div class='alert alert-danger'><h2 class='form-signin-heading'>SALAH COK, MATUR NUWUN!!!</h2></div></div><button type='button' class='btn btn-danger' data-dismiss='modal'><span class='fa fa-close'></span> Close</button></div><script type='text/javascript'>$('#myModal').modal('show');</script>");
        redirect('dashboard/pr');
      }
    }
    else
    {
      redirect('dashboard/pr');
    }
  }

  public function validation_login_anggota(){
    $this->form_validation->set_rules('username', 'Username', 'required');
    $this->form_validation->set_rules('password', 'Password', 'required');

    if ($this->form_validation->run()) 
    {
      $username = $this->input->post('username');
      $password = $this->input->post('password');
      $data = $this->model_akun->cek_login_akun_anggota($username, $password);
      if ($data) 
      {
          
          foreach ($data as $list) {
            $r = array();
            $r['id']          = $list['id'];
            $r['foto']        = $list['foto'];
            $r['username']    = $list['username'];
            $r['nama']        = $list['nama'];
            $r['kode_kom']    = $list['kode_kom'];
            $r['kode_rayon']    = $list['kode_rayon'];
            $this->session->set_userdata($r);
          }  
          //var_dump($tes);
          redirect('member');
      }
      else
      {
          $this->session->set_flashdata('error', "<div class='modal fade' id='myModal'><div class='modal-dialog'><div class='alert alert-danger'><h2 class='form-signin-heading'>SALAH COK, MATUR NUWUN!!!</h2></div></div><button type='button' class='btn btn-danger' data-dismiss='modal'><span class='fa fa-close'></span> Close</button></div><script type='text/javascript'>$('#myModal').modal('show');</script>");
          redirect('dashboard/member');
      }  
    }
    else
    {
      redirect('dashboard/member');
    }
  }
  
  public function logout(){
    $this->session->sess_destroy();
    
    redirect ('dashboard','refresh');
  }

}

  




