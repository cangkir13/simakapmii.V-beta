<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller{

  public function __construct(){
    parent::__construct();
    
    if(! $this->session->has_userdata('username'))
    {
      $this->session->set_flashdata("alert_pro", "<div class='modal fade' id='myModal'><div class='modal-dialog'><div class='alert alert-danger'><h2 class='form-signin-heading'>OJOK MEKSO, LOGIN RUMIYEN!!!</h2></div></div><button type='button' class='btn btn-danger' data-dismiss='modal'><span class='fa fa-close'></span> Close</button></div><script type='text/javascript'>$('#myModal').modal('show');</script>");
      redirect('dashboard/member', 'refresh');
    }
    
  }

  public function index(){
    $nama = $this->session->userdata('nama');
    $session = $this->session->userdata('username');
    $data['title'] = $nama;
    $data['data'] = $this->model_akun->get_member($session);
    $this->load->view('member/profile', $data);
  }

  public function printCV(){
    $nama = $this->session->userdata('nama');
    $session = $this->session->userdata('username');
    $data['title'] = $nama;
    $data['data'] = $this->model_akun->getVC($session);
    $this->load->view('member/printCV', $data);
  }

  public function editprofile()
  {
    $session = $this->session->userdata('username');
    $nama = $this->session->userdata('nama');
    $data['title'] = $nama;
    $data['data'] = $this->model_akun->get_member($session);
    $this->load->view('member/editprofile', $data);
  }

  public function proses_edit()
  {
    $id = $this->input->post('id');
    $jk = $this->input->post('jk');
    $jur = $this->input->post('jurusan');
    $nama = $this->input->post('nama');
    $username = $this->input->post('username');
    $nim = $this->input->post('nim');
    $password = $this->input->post('password');
    $email = $this->input->post('email');
    $blog = $this->input->post('blog');
    $fb = $this->input->post('fb');
    $tw = $this->input->post('tw');
    $ig = $this->input->post('ig');
    $lahir = $this->input->post('lahir');
    $tgl_lahir = $this->input->post('tgl_lahir');
    $tgl = date('Y-m-d', strtotime($tgl_lahir));
    $since = $this->input->post('since_enter');
    $sejak = date('Y-m-d', strtotime($since));
    $asal = $this->input->post('alamat_asal');
    $dimalang = $this->input->post('alamat_malang');
    $ayah = $this->input->post('ayah');
    $ibu = $this->input->post('ibu');
    $tlp_ortu = $this->input->post('tlp_ortu');
    $alamat_ortu = $this->input->post('alamat_ortu');
    $motto = $this->input->post('motto');
    $alasan = $this->input->post('alasan');
    $organisasi = $this->input->post('organisasi');
    $bakat = $this->input->post('bakat');
    $minat = $this->input->post('minat');

    $update_data = array(
          'jk'            => $jk,
          'jurusan'       => $jur,
          'nama'          => $nama,
          'username'      => $username,
          'since_enter'   => $sejak,
          'nim'           => $nim,
          'password'      => $password,
          'email'         => $email,
          'blog'          => $blog,
          'fb'            => $fb,
          'tw'            => $tw,
          'ig'            => $ig,
          'lahir'         => $lahir,
          'tgl_lahir'     => $tgl,
          'alamat_asal'   => $asal,
          'alamat_malang' => $dimalang,
          'ayah'          => $ayah,
          'ibu'           => $ibu,
          'tlp_ortu'      => $tlp_ortu,
          'alamat_ortu'   => $alamat_ortu,
          'motto'         => $motto,
          'alasan'        => $alasan,
          'organisasi'    => $organisasi,
          'bakat'         => $bakat,
          'minat'         => $minat
      );

    $where = array ('id' => $id);
    $res = $this->db->update('tb_kader_anggota', $update_data, $where);
    if ($res >= 1) {
      redirect('member');
    }
  }

  public function setting()
  {
    $session = $this->session->userdata('username');
    $nama = $this->session->userdata('nama');
    $data['title'] = $nama;
    $data['data'] = $this->model_akun->get_member($session);
    $this->load->view('member/setting', $data);
  }

  public function prosessetting()
  {
    $id = $this->input->post('id');
    $username = $this->input->post('username');
    $password = $this->input->post('password');

    $update_data = array(
          'username'      => $username,
          'password'      => $password
          
      );

    $where = array ('id' => $id);
    $res = $this->db->update('tb_kader_anggota', $update_data, $where);
    if ($res >= 1) {
      redirect('member');
    }
  }  

  public function editfoto(){
     $nama = $this->session->userdata('nama');
    $session = $this->session->userdata('username');
    $data['title'] = "Kader ".$nama;
    $data['data'] = $this->model_akun->get_member($session);
    
    $this->load->view('member/feupload', $data);
  }

//untuk menangani proses upload gambar yang di edit
public function updatefoto(){

  $this->load->library('upload');// library dapat di load di fungsi , di autoload atau di construc nya tinggal pilih salah satunya
  $nmfile = "file_".time(); //nama file saya beri nama langsung dan diikuti fungsi time
  $path   = './assets/foto/'; //path folder
  $config['upload_path'] = $path; //variabel path untuk config upload
  $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
  $config['max_size'] = '3000'; //maksimum besar file 2M
  $config['max_width']  = '4288'; //lebar maksimum 1288 px
  $config['max_height']  = '1968'; //tinggi maksimu 768 px
  $config['file_name'] = $nmfile; //nama yang terupload nantinya

  $this->upload->initialize($config);

  $idgbr      = $this->input->post('kode'); /* variabel id gambar */
  $filelama   = $this->input->post('filelama'); /* variabel file gambar lama */

  if($_FILES['filefoto']['name'])
  {
    if ($this->upload->do_upload('filefoto'))
    {
      $gbr = $this->upload->data();
      $data = array(
        'foto' =>$gbr['file_name'],
      );

      @unlink($path.$filelama);//menghapus gambar lama, variabel dibawa dari form

      $where =array('id'=>$idgbr); //array where query sebagai identitas pada saat query dijalankan
      $this->db->update('tb_kader_anggota',$data,$where); //akses model untuk menyimpan ke database

      $this->session->set_flashdata("pesan", "<div class=\"col-md-12\"><div class=\"alert alert-success\" id=\"alert\">Edit dan Upload gambar berhasil !!</div></div>"); //pesan yang muncul jika berhasil diupload pada session flashdata
      redirect('member'); //jika berhasil maka akan ditampilkan view vupload

    }else{  /* jika upload gambar gagal maka akan menjalankan skrip ini */
      $er_upload=$this->upload->display_errors(); /* untuk melihat error uploadnya apa */
      //pesan yang muncul jika terdapat error dimasukkan pada session flashdata
      $this->session->set_flashdata("pesan", "<div class=\"col-md-12\"><div class=\"alert alert-danger\" id=\"alert\">Gagal edit dan upload gambar !! ".$er_upload."</div></div>");
      redirect('member/editfoto'); //jika gagal maka akan ditampilkan form upload
    }
  }else{ /* jika file foto tidak ada maka query yg dijalankan adalah skrip ini  */

   
    $this->session->set_flashdata("pesan", "<div class=\"col-md-12\"><div class=\"alert alert-danger\" id=\"alert\">Berhasil edit, Gambar tidak ada diupload !!</div></div>");
    redirect('member'); /* jika berhasil maka akan kembali ke home upload */
    }
  }

}