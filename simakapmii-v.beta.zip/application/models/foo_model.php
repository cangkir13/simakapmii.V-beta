<?php
/**
* for super admin
*/
class Foo_Model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function aunt_log($username, $password)
	{
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$data = $this->db->get('superadmin');
		if ($data->num_rows() > 0) {
			return $data;
		}else{
			return FALSE;
		}
	}

	public function getadmin()
	{
		$data = $this->db->get('tb_admin');
		return $data->result_array();
	}

	public function hitrayon($id){
		$hit = "SELECT COUNT(tb_rayon.kode_kom) as jml
				FROM tb_rayon
				JOIN tb_komisariat
				ON tb_komisariat.kode_kom = tb_rayon.kode_kom 
				where tb_rayon.kode_kom = '$id'";
		$data = $this->db->query($hit);
		if ($data->num_rows() > 0) {
			return $data->result_array();
		}else{
			return false;
		}
	}

	public function hitkaderkom($id){
		$hit = "SELECT COUNT(tb_kader_anggota.kode_kom) as jml
				FROM tb_kader_anggota
				JOIN tb_komisariat
				ON tb_komisariat.kode_kom = tb_kader_anggota.kode_kom 
				where tb_kader_anggota.kode_kom = '$id'";
		$data = $this->db->query($hit);
		if ($data->num_rows() > 0) {
			return $data->result_array();
		}else{
			return false;
		}
	}

	public function hitkaderrayon($id){
		$hit = "SELECT COUNT(tb_kader_anggota.kode_rayon) as jml
				FROM tb_kader_anggota
				JOIN tb_rayon
				ON tb_rayon.kode_rayon = tb_kader_anggota.kode_rayon
				where tb_kader_anggota.kode_rayon = '$id'";
		$data = $this->db->query($hit);
		if ($data->num_rows() > 0) {
			return $data->result_array();
		}else{
			return false;
		}
	}
}
