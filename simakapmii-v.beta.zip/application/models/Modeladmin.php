<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modeladmin extends CI_Model {
 	public function getadmin($where=""){
 		$data = $this->db->query('select * from tb_admin '.$where);
 		return $data->result_array(); 
	}

	public function insert_admin($table_admin,$data){
		$res = $this->db->insert($table_admin,$data);
		return $res;	

	}

	public function update_admin($table_admin,$data, $where){
		$res = $this->db->update($table_admin, $data, $where);
		return $res;	
	
	}

	public function del_admin($table_admin,$data){
		$res = $this->db->delete($table_admin,$data);
		return $res;	

	}

	public function get_id($id){
		$query = "SELECT tb_komisariat.*, tb_rayon.*
				FROM tb_rayon JOIN tb_komisariat 
						ON tb_komisariat.kode_kom = tb_rayon.kode_kom 
					WHERE tb_komisariat.kode_kom = '$id'";
		$res = $this->db->query($query);
		return $res->result_array();
	}

	public function get_prof_kom($id){
		$query = "SELECT * FROM tb_komisariat Where kode_kom = '$id'";
		$res = $this->db->query($query);
		return $res->result_array();
	}

	public function get_prof_rayon($id){
		$query = "SELECT * FROM tb_rayon where kode_rayon = '$id'";
		$res = $this->db->query($query);
		return $res->result_array();
	}

	public function get_prof_anggota_kom($id){
		$query = "SELECT * FROM tb_kader_anggota 
				JOIN tb_komisariat ON tb_kader_anggota.kode_kom = tb_komisariat.kode_kom
				WHERE tb_kader_anggota.kode_kom = '$id'";
		$res = $this->db->query($query);
		return $res->result_array();
	}	

	public function get_prof_anggota_rayon($id){
		$query = "SELECT * FROM tb_kader_anggota 
				JOIN tb_rayon ON tb_rayon.kode_rayon = tb_rayon.kode_rayon 
				WHERE tb_rayon.kode_rayon = '$id'";
		$res = $this->db->query($query);
		return $res->result_array();
	}
}
