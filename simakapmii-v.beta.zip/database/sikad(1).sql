-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 18 Okt 2017 pada 11.38
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `sikad`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun_kom`
--

CREATE TABLE IF NOT EXISTS `akun_kom` (
  `id_akun_kom` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `kode_akun` varchar(200) NOT NULL,
  PRIMARY KEY (`id_akun_kom`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `akun_kom`
--

INSERT INTO `akun_kom` (`id_akun_kom`, `username`, `password`, `kode_akun`) VALUES
(1, 'asia', 'cffe819d4413b95dd8c35c0085930789', 'asia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun_rayon`
--

CREATE TABLE IF NOT EXISTS `akun_rayon` (
  `id_akun_rayon` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `kode_akun` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_akun_rayon`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `akun_rayon`
--

INSERT INTO `akun_rayon` (`id_akun_rayon`, `username`, `password`, `kode_akun`) VALUES
(1, 'agz', 'agz', 'agz'),
(2, 'isn', 'isn', 'isn');

-- --------------------------------------------------------

--
-- Struktur dari tabel `komisariat`
--

CREATE TABLE IF NOT EXISTS `komisariat` (
  `id_kom` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kom` varchar(200) NOT NULL,
  PRIMARY KEY (`id_kom`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `komisariat`
--

INSERT INTO `komisariat` (`id_kom`, `nama_kom`) VALUES
(1, 'Sunan Kalijaga (univ. malang)'),
(2, 'Brawijaya Malang (univ. brawijaya malang)');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rayon`
--

CREATE TABLE IF NOT EXISTS `rayon` (
  `id_rayon` int(11) NOT NULL AUTO_INCREMENT,
  `nama_rayon` varchar(200) NOT NULL,
  `id_kom` int(11) NOT NULL,
  PRIMARY KEY (`id_rayon`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `rayon`
--

INSERT INTO `rayon` (`id_rayon`, `nama_rayon`, `id_kom`) VALUES
(1, 'Rayon Teknik', 1),
(2, 'Rayon Al Ghozali', 1),
(3, 'Rayon pancasila', 2),
(4, 'Rayon Humaniora', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `superadmin`
--

CREATE TABLE IF NOT EXISTS `superadmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(200) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `superadmin`
--

INSERT INTO `superadmin` (`id`, `nama`, `username`, `password`) VALUES
(1, 'NawaIdea', 'sajadahcinta', '6f4816769f83fb8e0b62ee882ff03b13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE IF NOT EXISTS `tb_admin` (
  `id_user` int(35) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL,
  `email` varchar(35) NOT NULL,
  `level` enum('pc','pk','pr','member') NOT NULL,
  `divisi` varchar(35) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`id_user`, `user_name`, `pass`, `email`, `level`, `divisi`, `status`) VALUES
(1, 'root', '63a9f0ea7bb98050796b649e85481845', 'sopo_aku@ymail.com', 'pc', 'bidang2', 'active'),
(5, 'umar', '827ccb0eea8a706c4c34a16891f84e7b', 'uakh@gmail.ic', 'pc', 'makan', 'inactive');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kader_anggota`
--

CREATE TABLE IF NOT EXISTS `tb_kader_anggota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `kode` varchar(100) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `foto` text NOT NULL,
  `jk` enum('lk','pr') NOT NULL,
  `alamat_asal` text NOT NULL,
  `alamat_malang` text NOT NULL,
  `kode_kom` varchar(11) NOT NULL,
  `kode_rayon` varchar(11) NOT NULL,
  `tlp` int(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `blog` varchar(250) NOT NULL,
  `fb` varchar(250) NOT NULL,
  `tw` varchar(250) NOT NULL,
  `ig` varchar(250) NOT NULL,
  `lahir` varchar(200) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `motto` longtext NOT NULL,
  `ayah` varchar(200) NOT NULL,
  `ibu` varchar(200) NOT NULL,
  `alamat_ortu` text NOT NULL,
  `alasan` longtext NOT NULL,
  `organisasi` longtext NOT NULL,
  `bakat` text NOT NULL,
  `minat` text NOT NULL,
  `nim` int(20) NOT NULL,
  `tlp_ortu` int(20) NOT NULL,
  `since_enter` date NOT NULL,
  `kampus` varchar(200) NOT NULL,
  `fakultas` varchar(200) NOT NULL,
  `st_pc` enum('ya','tidak') NOT NULL,
  `st_pk` enum('ya','tidak') NOT NULL,
  `st_pr` enum('ya','tidak') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `tb_kader_anggota`
--

INSERT INTO `tb_kader_anggota` (`id`, `username`, `password`, `kode`, `nama`, `foto`, `jk`, `alamat_asal`, `alamat_malang`, `kode_kom`, `kode_rayon`, `tlp`, `email`, `blog`, `fb`, `tw`, `ig`, `lahir`, `tgl_lahir`, `motto`, `ayah`, `ibu`, `alamat_ortu`, `alasan`, `organisasi`, `bakat`, `minat`, `nim`, `tlp_ortu`, `since_enter`, `kampus`, `fakultas`, `st_pc`, `st_pk`, `st_pr`) VALUES
(6, 'suginem', '7792 ', '2014-004', 'suginem', '', 'pr', 'kalimantan mboh nangdi				', 'sudimoro							', 'asia', 'asia01', 0, 'suginem@gmail.com', 'mboh.com', 'fb', '', '', 'kalimantan', '1995-10-20', '							', 'ayah', 'ibu', '', '							', '							', '							', '							', 1220323, 0, '0000-00-00', '', '', 'ya', 'ya', 'ya');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_komisariat`
--

CREATE TABLE IF NOT EXISTS `tb_komisariat` (
  `id_kom` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kom` varchar(10) NOT NULL,
  `nama_kom` varchar(200) NOT NULL,
  `kampus` varchar(200) NOT NULL,
  `no_telp` int(20) NOT NULL,
  `email` varchar(250) NOT NULL,
  `website` varchar(250) NOT NULL,
  `fb` varchar(250) NOT NULL,
  `tw` varchar(250) NOT NULL,
  `ig` varchar(250) NOT NULL,
  `media` text NOT NULL,
  `alamat` text NOT NULL,
  `since` date NOT NULL,
  `ket` longtext NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`id_kom`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `tb_komisariat`
--

INSERT INTO `tb_komisariat` (`id_kom`, `kode_kom`, `nama_kom`, `kampus`, `no_telp`, `email`, `website`, `fb`, `tw`, `ig`, `media`, `alamat`, `since`, `ket`, `username`, `password`, `status`) VALUES
(6, 'asia', 'ASIA MALANG', '', 0, '', '', '', '', '', '', '', '0000-00-00', '', 'asia', 'cffe819d4413b95dd8c35c0085930789', 'active');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_rayon`
--

CREATE TABLE IF NOT EXISTS `tb_rayon` (
  `id_rayon` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `kode_rayon` varchar(10) NOT NULL,
  `nama_rayon` varchar(35) NOT NULL,
  `fakultas` varchar(35) NOT NULL,
  `kode_kom` varchar(200) DEFAULT NULL,
  `no_telp` int(20) NOT NULL,
  `media` text NOT NULL,
  `website` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `alamat` text NOT NULL,
  `since` date NOT NULL,
  `ket` longtext NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `fb` varchar(200) NOT NULL,
  `tw` varchar(200) NOT NULL,
  `ig` varchar(200) NOT NULL,
  PRIMARY KEY (`id_rayon`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `tb_rayon`
--

INSERT INTO `tb_rayon` (`id_rayon`, `username`, `password`, `kode_rayon`, `nama_rayon`, `fakultas`, `kode_kom`, `no_telp`, `media`, `website`, `email`, `alamat`, `since`, `ket`, `status`, `fb`, `tw`, `ig`) VALUES
(8, 'asia01', 'hasan', 'asia01', 'Al Hasani', '', 'asia', 0, '', '', '', '', '0000-00-00', '', 'active', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE IF NOT EXISTS `tb_user` (
  `id_user` int(35) NOT NULL AUTO_INCREMENT,
  `user` varchar(35) NOT NULL,
  `pass` varchar(35) NOT NULL,
  `level` enum('pc','pk','pr','') NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `user`, `pass`, `level`) VALUES
(1, 'root', 'root', 'pc'),
(2, 'komisariat', 'komisariat', 'pk'),
(3, 'rayon', 'rayon', 'pr');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_name` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_name`, `password`) VALUES
('dany', '1234'),
('pras', '4321');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
